const api = require("../../utils/api");
const { fixUrl } = require("../../utils/format");

Page({
  data: {
    user: null,
    attendanceSummary: null,
    loading: true,
    isAdminOrMinister: false,
    currentMonth: "",
    showLogoutModal: false,
  },

  onLoad() {
    if (!getApp().checkLogin()) return;
    const now = new Date();
    const m = (now.getMonth() + 1).toString().padStart(2, "0");
    this.setData({ currentMonth: `${now.getFullYear()}-${m}` });
  },

  onShow() {
    this.setData({
      isAdminOrMinister: getApp().hasRole("ADMIN", "MINISTER"),
      roleText: this.roleLabel(getApp().globalData.user?.role),
    });
    this.loadUser();
    this.loadAttendance();
  },

  async loadUser() {
    try {
      const res = await api.getMe();
      const user = res.user || res;
      // 补全相对路径图片
      if (user.avatarUrl) user.avatarUrl = fixUrl(user.avatarUrl);
      if (user.profileBgUrl) user.profileBgUrl = fixUrl(user.profileBgUrl);
      getApp().globalData.user = user;
      wx.setStorageSync('sxl_user', user);
      this.setData({ user });
    } catch (err) {
      // 回退到缓存数据
      this.setData({ user: getApp().globalData.user });
    }
  },

  async loadAttendance() {
    try {
      const res = await api.getMyAttendance(this.data.currentMonth);
      this.setData({ attendanceSummary: res.row, loading: false });
    } catch (err) {
      this.setData({ loading: false });
    }
  },

  onSettings() {
    wx.navigateTo({ url: "/pages/settings/settings" });
  },

  onReports() {
    wx.navigateTo({ url: "/pages/reports/reports" });
  },

  onLogout() {
    this.setData({ showLogoutModal: true });
  },

  cancelLogout() {
    this.setData({ showLogoutModal: false });
  },

  confirmLogout() {
    getApp().clearSession();
    wx.reLaunch({ url: "/pages/login/login" });
  },

  roleLabel(role) {
    const map = { ADMIN: "管理员", MINISTER: "部长", MEMBER: "部员" };
    return map[role] || role;
  },

  // 给 wxml 用的
  getRoleLabel() {
    return this.roleLabel(this.data.user?.role);
  },
});
